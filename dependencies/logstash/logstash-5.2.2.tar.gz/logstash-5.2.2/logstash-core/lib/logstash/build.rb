# encoding: utf-8
BUILD_INFO = {"build_date"=>"2017-02-24T17:46:55Z", "build_sha"=>"57984d20eb28b0df40a59077c600ec1a399d46f5", "build_snapshot"=>false}