# encoding: utf-8

# DO NOT EDIT
# this file acts as a placeholder for build information when executing
# logstash in dev mode (outside of a package build)
BUILD_INFO = {}
