#define SM185 
#define HAVE_JS_GET_STRING_CHARS_AND_LENGTH 1
#define JSSCRIPT_TYPE JSObject*
#define COUCHJS_NAME "couchjs"
#define PACKAGE "apache-couchdb"
#define PACKAGE_BUGREPORT "https://issues.apache.org/jira/browse/COUCHDB"
#define PACKAGE_NAME "Apache CouchDB"
#define PACKAGE_STRING "Apache CouchDB /bin/sh: line 1: git: command not found"
#define PACKAGE_VERSION "/bin/sh: line 1: git: command not found"
