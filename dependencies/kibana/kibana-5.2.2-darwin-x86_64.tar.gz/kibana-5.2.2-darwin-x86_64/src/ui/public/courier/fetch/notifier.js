import Notifier from 'ui/notify/notifier';

export default function CourierFetchNotifier() {
  return new Notifier({
    location: 'Courier Fetch'
  });
};
